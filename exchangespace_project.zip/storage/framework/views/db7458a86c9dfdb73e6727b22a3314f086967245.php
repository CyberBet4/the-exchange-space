<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            
            <?php if(session()->has('success')): ?>
              <div class="alert alert-success">
                  <?php echo e(session()->get('success')); ?>

              </div>
              <?php elseif(session()->has('error')): ?>
                <div class="alert alert-danger">
                  <?php echo e(session()->get('error')); ?>

              </div>
            <?php endif; ?>


            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">All Users</h4>
                    <p class="card-description"> All registered users are listed below. </p>
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> Full name </th>
                          <th> Email </th>
                          <th> Address </th>
                          <th> Actions </th>
                        </tr>
                      </thead>
                      
                      <tbody> 
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <tr>
                                    <td> <?php echo e($user->name); ?> </td>
                                    <td> <?php echo e($user->email); ?> </td>
                                    <td class="address"> <?php echo e($user->address); ?> </td> 
                                    <td class="d-flex"> 
                                        <a href=<?php echo e(url("/user-list", $user)); ?> class="btn btn-inverse-dark btn-sm mr-3">
                                         <i class="mdi mdi-eye mr-2"></i> View</a> 
                                    
                                    <?php if($user->id != auth()->user()->id): ?>
                                        <form action=<?php echo e(url("/user-delete", $user)); ?> method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <input type="hidden" name="id" value=<?php echo e($user->id); ?>>
                                            <button type="submit" onclick="deleteUser()" class="btn btn-danger btn-sm">
                                              <i class="mdi mdi-cancel mr-2"></i> Delete</button>
                                            <script>
                                                function deleteUser() {
                                                    return confirm("Are you sure you want to delete this user?");
                                                }
                                            </script>
                                        
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dumota/Documents/theexchangespace/resources/views/pages/admin/user-list.blade.php ENDPATH**/ ?>