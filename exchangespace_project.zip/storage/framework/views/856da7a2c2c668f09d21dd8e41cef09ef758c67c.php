<?php echo $__env->make('layouts.components.withdrawmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.components.fundmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>

                </div>
            <?php elseif(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('error')); ?>

                </div>
        <?php endif; ?>
      <div class="page-header">
        <h3 class="page-title"> Swap Transactions </h3>
      </div>

      <div class="row">
        <div class="col-12 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title">History</h4>
                <p class="card-description mb-4"> List of all transactions that happened </p>
                <table class="table table-hover">
                    <thead>
                      <tr>
                        <th>S/n</th>
                        <th>Description</th>
                        <th>Amount</th>
                        <th>Wallet</th>
                        <th>Date</th>
                      </tr>
                    </thead>
                    <tbody>
                        <input type="hidden" name="" value=<?php echo e($serial = 0); ?>>
                      
                        <?php if(count($transactions) > 0): ?>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($serial = $serial + 1); ?></td>
                            
                            <?php if($transaction->address != ""): ?>
                            <td class="text-gray"><i>(<?php echo e(strtoupper($transaction->wallet)); ?>) withdraw to external wallet</i> </td>
                            <?php else: ?>
                            <td class="text-gray"><i>(<?php echo e(strtoupper($transaction->wallet)); ?>) swap to internal wallet</i> </td>
                            <?php endif; ?>
                            <td class="text-gray">$<?php echo e($transaction->amount); ?> </td>
                            <td class="text-gray"> <b><?php echo e(strtoupper($transaction->newwallet)); ?>  
                              <?php echo e($transaction->address); ?></b> </td>
                              <td><?php echo e($transaction->created_at); ?></td>
                            
                            

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center text-gray">
                                <strong>No transactions yet</strong>
                            </td>
                        </tr>
                        <?php endif; ?>
                        
                      
                    </tbody>
                  </table>
              </div>
            </div>
          </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dumota/Documents/theexchangespace/resources/views/pages/transactions.blade.php ENDPATH**/ ?>