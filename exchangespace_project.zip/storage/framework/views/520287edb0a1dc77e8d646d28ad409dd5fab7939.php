

    <!-- Modal -->
    <div class="modal fade" id="withdrawmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Withdraw</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form action="<?php echo e(route("withdraw")); ?>" method="post">
                <?php echo csrf_field(); ?>
                <h6>From Internal Wallet</h6>
                <hr>
                <div class="form-group mb-3">
                  <label for="amount">Amount</label>
                  <input type="number" name="amount" class="form-control" value="0" id="exampleInputEmail1" placeholder="Enter amount">
                </div>

                <div class="form-group mb-3">
                    <label for="amount">Wallet Type</label> 
                    <select id="inner-wallet" class="form-control">
                      <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option id=<?php echo e($wallet->name); ?> value=<?php echo e($wallet->balance); ?>><?php echo e($wallet->coin); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="hidden" id="coinname" name="wallet" value=<?php echo e($wallets [0]->name); ?>>
                </div>

                <div class="form-group mb-3">
                  <label for="amount">Available Balance</label>
                  <input type="number" name="balance" class="form-control" value=<?php echo e($wallets [0]->balance); ?> id="balance" placeholder="Balance" disabled>
                </div>

                <br><br>
                
                  <h6>To Another Wallet</h6>
                <hr>
                
                  <div class="form-group mb-3">
                      <label for="amount">Enter wallet Address</label>
                      <input type="text" name="address" class="form-control" placeholder="Enter wallet">
                  </div>

                  <div class="form-group mb-3">
                    <label for="amount">Wallet Type</label> 
                    <select name="newwallet" class="form-control">
                      <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value=<?php echo e($wallet->coin); ?>><?php echo e($wallet->coin); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

              
            </div>
            <div class="modal-footer">
              
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
          </form>
          </div>
        </div>
      </div>
    

    <script>
      document.getElementById('inner-wallet').onchange = function() {
        var balance = document.getElementById('inner-wallet').value;
        document.getElementById('balance').value = balance;
        
        let x = document.getElementById("inner-wallet");
        document.getElementById('coinname').value = x.options[x.selectedIndex].id;
      }
    </script><?php /**PATH /Users/dumota/Documents/theexchangespace/resources/views/layouts/components/withdrawmodal.blade.php ENDPATH**/ ?>