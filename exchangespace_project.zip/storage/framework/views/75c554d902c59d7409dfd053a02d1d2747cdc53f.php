<?php echo $__env->make('layouts.components.withdrawmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.components.fundmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

    <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">

          
          
          
          
          
          <?php if(session()->has('success')): ?>
              <div class="alert alert-success">
                  <?php echo e(session()->get('success')); ?>

              </div>
              <?php elseif(session()->has('error')): ?>
                <div class="alert alert-danger">
                  <?php echo e(session()->get('error')); ?>

              </div>
              <?php elseif(session()->has('message')): ?>
                <div class="alert alert-info">
                  <?php echo e(session()->get('message')); ?>

              </div>
          <?php endif; ?>

          <div class="page-header">
           
            <h3 class="page-title">
              
              <span class="page-title-icon bg-gradient-primary text-white me-2">
                <i class="mdi mdi-home"></i>
              </span> Dashboard
            </h3>
            <nav aria-label="breadcrumb">
              <ul class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                  <span></span>Overview <i class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                </li>
              </ul>
            </nav>
          </div>


          

          <div class="row">
            <div class="d-none">
              <?php echo e($count = 0); ?>

            </div>
            
            <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($wallet->balance > 0): ?>
              <div class="col-md-4 stretch-card grid-margin">
                <?php if(2 >= $value/2 && $value % 2 == 0): ?>
                <div class="card bg-gradient-success card-img-holder text-white">
                <?php elseif($value % 2 == 0): ?>
                  <div class="card bg-gradient-danger card-img-holder text-white">
                <?php else: ?>
                <div class="card bg-gradient-info card-img-holder text-white">
                  <?php endif; ?> 
                  <div class="card-body">
                    <img src=<?php echo e(asset("/images/dashboard/circle.svg")); ?> class="card-img-absolute" alt="circle-image" />
                      <h4 class="font-weight-normal mb-3"><?php echo e($wallet->coin); ?> <i class="mdi mdi-chart-line mdi-24px float-right"></i>
                    </h4>
                    <h2 class="mb-5">$<?php echo e($wallet->balance); ?></h2>
                    
                    
                   </div>
                </div>
              </div>
              <div class="d-none">
                <?php echo e($count++); ?>

              </div>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

          
          <div class="row">
            <?php if($count == 0): ?>
            <div class="col-12">
                <div class="bg-gradient-info jumbotron pt-3 pb-3 text-white d-flex align-items-center justify-space-between" style="justify-content: space-between">
                  <div class="d-flex justify-content-center align-items-center">
                    <div class="mr-3">
                      <i class="mdi mdi-information" style="font-size: 44px;"></i>
                    </div>
                    
                    <div>
                      <h4 class="">No wallet present</h4>
                      <p class="text-white-50 mb-0">
                        Fund your swappable wallet to start trading
                      </p>
                    </div>
                    
                  </div>

                  
                  
                  <img src="<?php echo e(asset('/images/dashboard/girl-using-mobile-net-banking.svg')); ?>" style="max-width: 250px;" class="img-fluid" alt="">
                </div>
            </div>
            <?php endif; ?>
          </div>

          

          <div class="row">
            <div class="col-md-4 stretch-card grid-margin">
              <div class="card card-img-holder">
                <div class="card-body">
                  <img src=<?php echo e(asset("/images/dashboard/circle.svg")); ?> class="card-img-absolute" alt="circle-image" />
                  <h4 class="font-weight-normal mb-3">Active Swaps
                  </h4>
                  <h2 class="mb-5"><?php echo e(auth()->user()->active_swap); ?></h2>
                  
                </div>
              </div>
            </div>
            <div class="col-md-4 stretch-card grid-margin">
              <div class="card card-img-holder">
                <div class="card-body">
                  <img src=<?php echo e(asset("/images/dashboard/circle.svg")); ?> class="card-img-absolute" alt="circle-image" />
                  <h4 class="font-weight-normal mb-3">Completed Swaps 
                  </h4>
                  <h2 class="mb-5"><?php echo e(auth()->user()->completed_swap); ?></h2>
                  
                </div>
              </div>
            </div>
            <div class="col-md-4 stretch-card grid-margin">
              <div class="card card-img-holder">
                <div class="card-body">
                  <img src=<?php echo e(asset("/images/dashboard/circle.svg")); ?> class="card-img-absolute" alt="circle-image" />
                  <h4 class="font-weight-normal mb-3">Total Swaps
                  </h4>
                  <h2 class="mb-5"><?php echo e(auth()->user()->active_swap + auth()->user()->completed_swap); ?> </h2>
                  
                </div>
              </div>
            </div>
          </div>


        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid d-flex justify-content-between">
            <span class="text-muted d-block text-center text-sm-start d-sm-inline-block">Copyright © Exchangespace 2022</span>
            
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dumota/Documents/theexchangespace/resources/views/pages/dashboard.blade.php ENDPATH**/ ?>