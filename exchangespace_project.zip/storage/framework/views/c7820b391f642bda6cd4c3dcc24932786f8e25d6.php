<?php $__env->startSection('content'); ?>
<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Sign Up</h2>
          <ol>
            <li><a href=<?php echo e(url('/')); ?>>Home</a></li>
            <li>Sign Up</li>
          </ol>
        </div>

        

      </div>
    </section><!-- End Breadcrumbs -->

    <section class="inner-page contact">
      <div class="container">
        <div class="row">
          <div class="col-12 d-flex" style="justify-content: center;">
            <div style="max-width: 1000px;">
              <h2 class="text-center">Create an Account</h2>
              <p class="mb-5 text-center"> It's free and only takes a minute.</p>
              <form action=<?php echo e(route("register")); ?> method="post" role="form" class="php-email-form">
                <?php echo csrf_field(); ?>
                  <div class=" form-group">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required />
                    <div class="validate">
                      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger text-sm"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                  
                  <div class="form-group mt-3">
                    <!-- input for contact address -->
                    <input type="text" class="form-control" name="address" placeholder="Contact Address" data-rule="email" data-msg="Please enter a valid email" required />
                    <div class="validate">
                      <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger text-sm"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>

                <div class="form-group mt-3">
                  <input type="text" class="form-control" name="email" placeholder="Email Address" required>
                  <div class="validate">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>

                <div class="form-group mt-3">
                  <input type="password" class="form-control" name="password" placeholder="Password" required>
                  <div class="validate">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div> 
                </div>

                <div class="form-group mt-3">
                  <input type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password" required>
                  <div class="validate">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div> 
                </div>

                <div class="my-3">
                  <!-- <div class="loading">Loading</div>
                  <div class="error-message"></div>
                  <div class="sent-message">Your message has been sent. Thank you!</div> -->
                </div>
                <div class="text-center"><button type="submit" style="width: 100%;" class="btn btn-primary">Sign Up</button></div>
                <div>
                  <p class="text-center mt-3">Already have an account? <a href=<?php echo e(url('/login')); ?>>Login</a></p>
                </div>
              </form>
            </div>
            
          </div>
        </div>
      </div>
    </section>

  </main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('unauth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dumota/Documents/theexchangespace/resources/views/unauth/pages/register.blade.php ENDPATH**/ ?>