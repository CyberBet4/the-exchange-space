<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($user->name); ?> has requested a withdraw.

Information details:
<?php echo e($user->name); ?> 
(<?php echo e($user->email); ?>)

Withdraw request:
<?php echo e($user->name); ?> initiated a withdraw of <?php echo e($amount); ?> (<?php echo e($wallet); ?>) <br>

To (User wallet): (<?php echo e($newwallet); ?>) <?php echo e($address); ?>

<br>
Go to <?php echo e(config('app.name')); ?> to fulfill this request.
<?php $__env->startComponent('mail::button', ['url' => route('user-list')]); ?>
View in dashboard
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/dumota/Documents/theexchangespace/resources/views/emails/withdraw_request.blade.php ENDPATH**/ ?>