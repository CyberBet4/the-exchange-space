<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($user->name); ?> has requested a deposit.

Information details:
<?php echo e($user->name); ?> 
(<?php echo e($user->email); ?>)

Deposit request:
<?php echo e($user->name); ?> made a deposit of <?php echo e($amount); ?> (<?php echo e($coin); ?>) to <?php echo e($cointype); ?>:
# <?php echo e($user->wallet); ?> <br>

To be swapped to (User preferred wallet): <?php echo e($usercoin); ?>


<?php $__env->startComponent('mail::button', ['url' => route('user-list')]); ?>
View in dashboard
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/dumota/Documents/theexchangespace/resources/views/emails/deposit_request.blade.php ENDPATH**/ ?>