@include('unauth.layouts.header')
@yield('content')
@include('unauth.layouts.footer')